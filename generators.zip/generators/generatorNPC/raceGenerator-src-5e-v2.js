var race_collection = race_collection || {};
var race_collection_keys = race_collection_keys || {};
var race_list = race_list || [];

race_collection_keys = [
        'Monsterous',
        'Planer',
        'Halfbreeds',
        'Gnome',
        'Elven',
        'Halfling',
        'Human',
        'Undead',
        'Dwarven'
        ];

race_collection = {
    "Monsterous": {
        "Aarakocra": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Aarakocra",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "M",
            "source": "Elemental Evil Player's Companion",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Flight",
                "text": ["You have a flying speed of 50 feet. To use this speed, you can't be wearing medium or heavy armor."]
            }, {
                "name": "Talons",
                "text": ["You are proficient with your unarmed strikes, which deal 1d4 slashing damage on a hit."]
            }, {
                "name": "Language",
                "text": ["You can speak, read, and write Common, Aarakocra, and Auran."]
            }],
            "species": "Monsterous"
        },
        "Hawk-Headed Aven": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 2
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Hawk-Headed Aven",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "M",
            "source": "Plane Shift Amonkhet",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Flight",
                "text": ["You have a flying speed of 30 feet. You can't use your flying speed while you wear medium or heavy armor. (If your campaign uses the variant rule for encumbrance, you can't use your flying speed if you are encumbered.)"]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Aven."]
            }, {
                "name": "Hawkeyed",
                "text": ["You have proficiency in the Perception skill. In addition, attacking at long range doesn't impose disadvantage on your ranged weapon attack rolls."]
            }],
            "species": "Monsterous"
        },
        "Ibis-Headed Aven": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Ibis-Headed Aven",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "M",
            "source": "Plane Shift Amonkhet",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Flight",
                "text": ["You have a flying speed of 30 feet. You can't use your flying speed while you wear medium or heavy armor. (If your campaign uses the variant rule for encumbrance, you can't use your flying speed if you are encumbered.) "]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Aven."]
            }, {
                "name": "Kefnet's Blessing",
                "text": ["You can add half your proficiency bonus, rounded down, to any Intelligence check you make that doesn't already include your proficiency bonus."]
            }],
            "species": "Monsterous"
        },
        "Bugbear": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 1,
                "STR": 2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Bugbear",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Stealth",
            "traits": [{
                "name": "Darkvision",
                "text": ["You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Long-Limbed",
                "text": ["When you make a melee attack on your turn, your reach for it is 5 feet greater than normal."]
            }, {
                "name": "Powerful Build",
                "text": ["You count as one size larger when determining your carrying capacity and the weight you can push, drag, or lift."]
            }, {
                "name": "Sneaky",
                "text": ["You are proficient in the Stealth skill."]
            }, {
                "name": "Surprise Attack",
                "text": ["If you surprise a creature and hit it with an attack on your first turn in combat, the attack deals an extra 2d6 damage to it. You can use this trait only once per combat."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Goblin."]
            }],
            "species": "Monsterous"
        },
        "Firbolg": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 2
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Firbolg",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Firbolg Magic",
                "text": ["You can cast detect magic and disguise self with this trait, using Wisdom as your spellcasting ability for them. Once you cast either spell, you can't cast it again with this trait until you finish a short or long rest. When you use this version of disguise self, you can seem up to 3 feet shorter than normal, allowing you to more easily blend in with humans and elves."]
            }, {
                "name": "Hidden Step",
                "text": ["As a bonus action, you can magically turn invisible until the start of your next turn ot until you attack, make a damage roll, or force someone to make a saving throw. Once you use this trait, you can't use it again until you finish a short or long rest."]
            }, {
                "name": "Powerful Build",
                "text": ["You count as one size larger when determining your carrying capacity and the weight you can push, drag, or lift."]
            }, {
                "name": "Speech of Beast and Leaf",
                "text": ["You have the ability to communicate in a limited manner with beasts and plants. They can understand the meaning of your words, though you have no special ability to understand them in return. You have advantage on all Charisma checks you make to influence them."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and Giant."]
            }],
            "species": "Monsterous"
        },
        "Goblin": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Goblin",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "S",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 8,
                "maxage": 60
            },
            "proficiency": "",
            "traits": [{
                "name": "Darkvision",
                "text": ["You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Fury of the Small",
                "text": ["When you damage a creature with an attack or a spell and the creature's size is larger than yours, you can cause the attack or spell to deal extra damage to the creature. The extra damage equals your level. Once you use this trait, you can't use it again until you finish a short or long rest."]
            }, {
                "name": "Nimble Escape",
                "text": ["You can take the Disengage or Hide action as a bonus action on each of your turns."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Goblin."]
            }],
            "species": "Monsterous"
        },
        "Grogtag Tribe Goblin": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Grogtag Tribe Goblin",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 8,
                "maxage": 60
            },
            "proficiency": "Animal Handling",
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Grit",
                "text": ["You have resistance to fire damage and psychic damage. In addition, when you are wearing no armor, your AC is equal to 11 + your Dexterity modifier."]
            }, {
                "name": "Grogtag Tamer",
                "text": ["You have proficiency in the Animal Handling skill."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Goblin."]
            }],
            "species": "Monsterous"
        },
        "Lavastep Tribe Goblin": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Lavastep Tribe Goblin",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 8,
                "maxage": 60
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Grit",
                "text": ["You have resistance to fire damage and psychic damage. In addition, when you are wearing no armor, your AC is equal to 11 + your Dexterity modifier."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Goblin."]
            }, {
                "name": "Lavastep Grit",
                "text": ["You have advantage on Dexterity (Stealth) checks made to hide in rocky or subterranean environments."]
            }],
            "species": "Monsterous"
        },
        "Tuktuk Tribe Goblin": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Tuktuk Tribe Goblin",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 8,
                "maxage": 60
            },
            "proficiency": "Thieves' Tools",
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Grit",
                "text": ["You have resistance to fire damage and psychic damage. In addition, when you are wearing no armor, your AC is equal to 11 + your Dexterity modifier."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Goblin."]
            }, {
                "name": "Tuktuk Cunning",
                "text": ["You have proficiency with thieves' tools."]
            }],
            "species": "Monsterous"
        },
        "Goliath": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Goliath",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Elemental Evil Player's Companion",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Athletics",
            "traits": [{
                "name": "Natural Athlete",
                "text": ["You have proficiency in the Athletics skill."]
            }, {
                "name": "Stone's Endurance",
                "text": ["You can focus yourself to occasionally shrug off injury. When you take damage, you can use your reaction to roll a d12. Add your Constitution modifier to the number rolled, and reduce the damage by that total. After you use this trait, you can't use it again until you finish a short or long rest."]
            }, {
                "name": "Powerful Build",
                "text": ["You count as one size larger when determining your carrying capacity and the weight you can push, drag, or lift."]
            }, {
                "name": "Mountain Born",
                "text": ["You're acclimated to high altitude, including elevations above 20,000 feet. You're also naturally adapted to cold climates, as described in chapter 5 of the Dungeon Master's Guide."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Giant."]
            }],
            "species": "Monsterous"
        },
        "Hobgoblin": {
            "stats": {
                "INT": 1,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Hobgoblin",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "proficiency": "",
            "traits": [{
                "name": "Darkvision",
                "text": ["You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Martial Training",
                "text": ["You are proficient with two martial weapons of your choice and with light armor."]
            }, {
                "name": "Saving Face",
                "text": ["Hobgoblins are careful not to show weakness in front of their allies, for fear of losing status. If you miss with an attack roll or fail an ability check or a saving throw, you can gain a bonus to the roll equal to the number of allies you can see within 30 feet of you (maximum bonus of +5). Once you use this trait, you can't use it again until you finish a short or long rest."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Goblin."]
            }],
            "species": "Monsterous"
        },
        "Kenku": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Kenku",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Expert Forgery",
                "text": ["You can duplicate other creatures' handwriting and craftwork. You have advantage on all checks made to produce forgeries or duplicates of existing objects."]
            }, {
                "name": "Kenku Training",
                "text": ["You are proficient in your choice of two of the following skills: Acrobatics, Deception, Stealth, and Sleight of Hand."]
            }, {
                "name": "Mimicry",
                "text": ["You can mimic sounds you have heard, including voices. A creature that hears the sounds can tell they are imitations with a successful Wisdom (Insight) check opposed by your Charisma (Deception) check."]
            }, {
                "name": "Languages",
                "text": ["You can read and write Common and Auran, but you can only speak using your Mimicry trait."]
            }],
            "species": "Monsterous"
        },
        "Kobold": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": -2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Kobold",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "S",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Darkvision",
                "text": ["You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Grovel, Cower, and Beg",
                "text": ["As an action on your turn, you can cower pathetically to distract nearby foes. Until the end of your next turn, your allies gain advantage on attack rolls against enemies within 10 feet of you that you can see. Once you uses this trait, you can't use it again until you finish a short or long rest."]
            }, {
                "name": "Pack Tactics",
                "text": ["You have advantage on an attack roll against a creature if at least one of your allies is within 5 feet of the creature and the ally isn't incapacitated."]
            }, {
                "name": "Sunlight Sensitivity",
                "text": ["You have disadvantage on attack rolls and on Wisdom (Perception) checks that rely on sight when you, the target of your attack, or whatever you are trying to perceive is in direct sunlight."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Draconic."]
            }],
            "species": "Monsterous"
        },
        "Lizardfolk": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Lizardfolk",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "proficiency": "",
            "traits": [{
                "name": "Swim Speed",
                "text": ["You have a swimming speed of 30 feet."]
            }, {
                "name": "Bite",
                "text": ["Your fanged maw is a natural weapon, which you can use to make unarmed strikes. If you hit with it, you deal piercing damage equal to 1d6 + your Strength modifier, instead of the bludgeoning damage  normal for an unarmed strike."]
            }, {
                "name": "Cunning Artisan",
                "text": ["As part of a short rest, you can harvest bone and hide from a slain beast, construct, dragon, monstrosity, or plant creature of size small or larger to create one of the following items: a shield, a club, a javelin, or 1d4 darts or blowgun needles. To use this trait, you need a blade, such as a dagger, or appropriate artisan's tools, such as leatherworker's tools."]
            }, {
                "name": "Hold Breath",
                "text": ["You can hold your breath for up to 15 minutes at a time."]
            }, {
                "name": "Hunter's Lore",
                "text": ["You gain proficiency with two of the following skills of your choice: Animal Handling, Nature, Perception, Stealth, and Survival."]
            }, {
                "name": "Natural Armor",
                "text": ["You have tough, scaly skin. When you aren't wearing armor, your AC is 13 + your Dexterity modifier. You can use your natural armor to determine your AC if the armor you wear would leave you with a lower AC. A shield's benefits apply as normal while you use your natural armor."]
            }, {
                "name": "Hungry Jaws",
                "text": ["In battle, you can throw yourself into a vicious feeding frenzy. As a bonus action, you can make a special attack with your bite. If the attack hits, it deals its normal damage, and you gain temporary hit points equal to your Constitution modifier (minimum of 1), and you can't use this trait again until you finish a short or long rest."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Draconic."]
            }],
            "species": "Monsterous"
        },
        "Cosi Creed Merfolk": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Cosi Creed Merfolk",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Sleight of Hand, Stealth",
            "traits": [{
                "name": "Amphibious",
                "text": ["You can breathe air and water."]
            }, {
                "name": "Cantrip",
                "text": ["You know one cantrip of your choice from the bard spell list. Charisma is your spellcasting ability for it."]
            }, {
                "name": "Creed of the Trickster",
                "text": ["You have proficiency in the Sleight of Hand and Stealth skills."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Merfolk, and one extra language of your choice."]
            }, {
                "name": "Swimming",
                "text": ["You have a swimming speed of 30 feet."]
            }],
            "species": "Monsterous"
        },
        "Emeria Creed Merfolk": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 2
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Emeria Creed Merfolk",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Deception, Persuasion",
            "traits": [{
                "name": "Amphibious",
                "text": ["You can breathe air and water."]
            }, {
                "name": "Cantrip",
                "text": ["You know one cantrip of your choice from the druid spell list. Wisdom is your spellcasting ability for it."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Merfolk, and one extra language of your choice."]
            }, {
                "name": "Swimming",
                "text": ["You also have a swimming speed of 30 feet."]
            }, {
                "name": "Wind Creed Manipulation",
                "text": ["You have proficiency in the Deception and Persuasion skills."]
            }],
            "species": "Monsterous"
        },
        "Ula Creed Merfolk": {
            "stats": {
                "INT": 2,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Ula Creed Merfolk",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Amphibious",
                "text": ["You can breathe air and water."]
            }, {
                "name": "Cantrip",
                "text": ["You know one cantrip of your choice from the wizard spell list. Intelligence is your spellcasting ability for it."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Merfolk, and one extra language of your choice."]
            }, {
                "name": "Swimming",
                "text": ["You also have a swimming speed of 30 feet."]
            }, {
                "name": "Water Creed Navigation",
                "text": ["You have proficiency with navigator tools and in the Survival skill."]
            }],
            "species": "Monsterous"
        },
        "Amonkhet Minotaur": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Amonkhet Minotaur",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Amonkhet",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Natural Weapon",
                "text": ["You can use your horns as a natural weapon to make unarmed strikes. If you hit with your horns, you deal bludgeoning damage equal to 1d6 + your Strength modifier."]
            }, {
                "name": "Menacing",
                "text": ["You gain proficiency in the Intimidation skill."]
            }, {
                "name": "Relentless Endurance",
                "text": ["When you are reduced to 0 hit points but not killed outright, you can drop to 1 hit point instead. You can't use this feature again until you finish a long rest."]
            }, {
                "name": "Savage Attacks",
                "text": ["When you score a critical hit with a melee weapon attack, you can roll one of the weapon's damage dice one additional time and add it to the extra damage of the critical hit."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Minotaur."]
            }],
            "species": "Monsterous"
        },
        "Krynn Minotaur": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Krynn Minotaur",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Waterborne Adventures",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Conqueror's Virtue",
                "text": ["From a young age, you focused on one of the three virtues of strength, cunning, or intellect. Your choice of your Strength, Intelligence, or Wisdom score increases by 1."]
            }, {
                "name": "Horns",
                "text": ["You are never unarmed. You are proficient with your horns, which are a melee weapon that deals 1d10 piercing damage. Your horns grant you advantage on all checks made to shove a creature, but not to avoid being shoved yourself."]
            }, {
                "name": "Goring Rush",
                "text": ["When you use the Dash action during your turn, you can make a melee attack with your horns as a bonus action."]
            }, {
                "name": "Hammering Horns",
                "text": ["When you use the Attack action during your turn to make a melee attack, you can attempt to shove a creature with your horns as a bonus action. You cannot use this shove attempt to knock a creature prone."]
            }, {
                "name": "Labyrinthine Recall",
                "text": ["You can perfectly recall any path you have traveled."]
            }, {
                "name": "Sea Reaver",
                "text": ["You gain proficiency with navigator's tools and vehicles (water)."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common."]
            }],
            "species": "Monsterous"
        },
        "Naga": {
            "stats": {
                "INT": 1,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Naga",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Amonkhet",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Size",
                "text": ["Naga stand about 5 feet tall when upright, but the total length of their bodies, head to tail, ranges from 10 to as much as 20 feet. Your size is Medium."]
            }, {
                "name": "Speed Burst",
                "text": ["By lowering your body to the ground and propelling yourself with your arms, you can move more quickly for a time. As a bonus action on your turn, if you have both hands free, you can increase your walking speed by 5 feet until the end of your turn."]
            }, {
                "name": "Natural Weapons",
                "text": ["Your fanged maw and constricting serpentine body are natural weapons, which you can use to make unarmed strikes.", "If you hit with your bite, you deal piercing damage equal to 1d4 + your Strength modifier, and your target must make a Constitution saving throw (DC 8 + your proficiency bonus + your Constitution modifier). On a failed save, the target takes 1d4 poison damage.", "If you hit with your constrict attack, you deal bludgeoning damage equal to 1d6 + your Strength modifier, and the target is grappled (escape DC 8 + your proficiency bonus + your Strength modifier). Until this grapple ends, the target is restrained, and you can't constrict another target."]
            }, {
                "name": "Poison Immunity",
                "text": ["You are immune to poison damage and can't be poisoned."]
            }, {
                "name": "Poison Affinity",
                "text": ["You gain proficiency with the poisoner's kit."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Naga."]
            }],
            "species": "Monsterous"
        },
        "Orc": {
            "stats": {
                "INT": -2,
                "CON": 1,
                "DEX": 0,
                "STR": 2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Orc",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "proficiency": "Intimidation",
            "traits": [{
                "name": "Darkvision",
                "text": ["You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Aggressive",
                "text": ["As a bonus action, you can move up to your movement speed toward a hostile creature you can see or hear. You must end this move closer to the enemy than you started."]
            }, {
                "name": "Menacing",
                "text": ["You are trained in the Intimidation skill."]
            }, {
                "name": "Powerful Build",
                "text": ["You count as one size larger when determining your carrying capacity and the weight you can push, drag, or lift."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Orc."]
            }],
            "species": "Monsterous"
        },
        "Beasthide Shifter": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Beasthide Shifter",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Your lycanthropic heritage grants you the ability to see in dark conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Shifting",
                "text": ["On your turn, you can shift as a bonus action. Shifting lasts for 1 minute or until you end it on your turn as a bonus action.", null, "While shifting, you gain temporary hit points equal to your level + your Constitution bonus (minimum of 1). You also gain a feature that depends on your shifter subrace, described below.", null, "You must finish a short or long rest before you can shift again."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Sylvan."]
            }, {
                "name": "Shifting Feature",
                "text": ["While shifting, you gain a +1 bonus to AC."]
            }],
            "species": "Monsterous"
        },
        "Cliffwalk Shifter": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Cliffwalk Shifter",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Your lycanthropic heritage grants you the ability to see in dark conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Shifting",
                "text": ["On your turn, you can shift as a bonus action. Shifting lasts for 1 minute or until you end it on your turn as a bonus action.", null, "While shifting, you gain temporary hit points equal to your level + your Constitution bonus (minimum of 1). You also gain a feature that depends on your shifter subrace, described below.", null, "You must finish a short or long rest before you can shift again."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Sylvan."]
            }, {
                "name": "Shifting Feature",
                "text": ["While shifting, you gain a climb speed of 30 feet."]
            }],
            "species": "Monsterous"
        },
        "Longstride Shifter": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Longstride Shifter",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Your lycanthropic heritage grants you the ability to see in dark conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Shifting",
                "text": ["On your turn, you can shift as a bonus action. Shifting lasts for 1 minute or until you end it on your turn as a bonus action.", null, "While shifting, you gain temporary hit points equal to your level + your Constitution bonus (minimum of 1). You also gain a feature that depends on your shifter subrace, described below.", null, "You must finish a short or long rest before you can shift again."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Sylvan."]
            }, {
                "name": "Shifting Feature",
                "text": ["While shifting, you can use the Dash action as a bonus action."]
            }],
            "species": "Monsterous"
        },
        "Longtooth Shifter": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 1,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Longtooth Shifter",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Your lycanthropic heritage grants you the ability to see in dark conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Shifting",
                "text": ["On your turn, you can shift as a bonus action. Shifting lasts for 1 minute or until you end it on your turn as a bonus action.", null, "While shifting, you gain temporary hit points equal to your level + your Constitution bonus (minimum of 1). You also gain a feature that depends on your shifter subrace, described below.", null, "You must finish a short or long rest before you can shift again."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Sylvan."]
            }, {
                "name": "Shifting Feature",
                "text": ["While shifting, you can make a bite attack as an action. This is a melee weapon attack that uses Strength for its attack roll and damage bonus and deals 1d6 piercing damage. If this attack hits a target that is your size or smaller, the target is also grappled."]
            }],
            "species": "Monsterous"
        },
        "Razorclaw Shifter": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Razorclaw Shifter",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Your lycanthropic heritage grants you the ability to see in dark conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Shifting",
                "text": ["On your turn, you can shift as a bonus action. Shifting lasts for 1 minute or until you end it on your turn as a bonus action.", null, "While shifting, you gain temporary hit points equal to your level + your Constitution bonus (minimum of 1). You also gain a feature that depends on your shifter subrace, described below.", null, "You must finish a short or long rest before you can shift again."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Sylvan."]
            }, {
                "name": "Shifting Feature",
                "text": ["While shifting, you can make an unarmed strike as a bonus action. You can use your Dexterity for its attack roll and damage bonus, and this attack deals slashing damage."]
            }],
            "species": "Monsterous"
        },
        "Wildhunt Shifter": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Wildhunt Shifter",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Your lycanthropic heritage grants you the ability to see in dark conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Shifting",
                "text": ["On your turn, you can shift as a bonus action. Shifting lasts for 1 minute or until you end it on your turn as a bonus action.", null, "While shifting, you gain temporary hit points equal to your level + your Constitution bonus (minimum of 1). You also gain a feature that depends on your shifter subrace, described below.", null, "You must finish a short or long rest before you can shift again."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Sylvan."]
            }, {
                "name": "Shifting Feature",
                "text": ["While shifting, you gain advantage on all Wisdom-based checks and saving throws."]
            }],
            "species": "Monsterous"
        },
        "Tabaxi": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Tabaxi",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 18,
                "maxage": 60
            },
            "proficiency": "Perception, Stealth",
            "traits": [{
                "name": "Darkvision",
                "text": ["You have a cat's keen senses, especially in the dark. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Feline Agility",
                "text": ["Your reflexes and agility allow you to move with a burst of speed. When you move on your turn in combat, you can double your speed until the end of the turn. Once you use this trait, you can't use it again until you move 0 feet on one of your turns."]
            }, {
                "name": "Cat's Claws",
                "text": ["Because of your claws, you have a climbing speed of 20 feet. In addition, your claws are natural weapons, which you can use to make unarmed strikes. If you hit with them, you deal slashing damage equal to 1d4 + your Strength modifier, instead of the bludgeoning damage normal for an unarmed strike."]
            }, {
                "name": "Cat's Talents",
                "text": ["You have proficiency in the Perception and Stealth skills."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and one other language of your choice."]
            }],
            "species": "Monsterous"
        },
        "Triton": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Triton",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Swim Speed",
                "text": ["You have a swimming speed of 30 feet."]
            }, {
                "name": "Amphibious",
                "text": ["You can breathe air and water."]
            }, {
                "name": "Control Air and Water",
                "text": ["A child of the sea, you can call on the magic of elemental air and water. You can cast fog cloud with this trait. Starting at 3rd level, you can cast gust of wind with it, and starting at 5th level, you can also cast wall of water with it. Once you cast a spell with this trait, you can't do so again until you finish a long rest. Charisma is your spellcasting ability for these spells."]
            }, {
                "name": "Emissary of the Sea",
                "text": ["Aquatic beasts have an extraordinary affinity with your people. You can communicate simple ideas with beasts that can breathe water. They can understand the meaning of your words, though you have no special ability to understand them in return."]
            }, {
                "name": "Guardians of the Depths",
                "text": ["Adapted to even the most extreme ocean depths, you have resistance to cold damage, and you ignore any of the drawbacks caused by a deep, underwater environment."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Primordial."]
            }],
            "species": "Monsterous"
        },
        "Warforged": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Warforged",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Composite Plating",
                "text": ["Your construction incorporates wood and metal, granting you a +1 bonus to Armor Class."]
            }, {
                "name": "Living Construct",
                "text": ["Even though you were constructed, you are a living creature. You are immune to disease. You do not need to eat or breathe, but you can ingest food and drink if you wish.", "Instead of sleeping, you enter an inactive state for 4 hours each day. You do not dream in this state; you are fully aware of your surroundings and notice approaching enemies and other events as normal."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and one other language of your choice."]
            }],
            "species": "Monsterous"
        },
        "Yuan-ti Pureblood": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Yuan-ti Pureblood",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Darkvision",
                "text": ["You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Innate Spellcasting",
                "text": ["You know the poison spray cantrip. You can cast animal friendship an unlimited number of times with this trait, but you can target only snakes with it. Starting at 3rd level, you can also cast suggestion with this trait. Once you cast it, you can't do so again until you finish a long rest. Charisma is your spellcasting ability for these spells."]
            }, {
                "name": "Magic Resistance",
                "text": ["You have advantage on saving throws against spells and other magical effects."]
            }, {
                "name": "Poison Immunity",
                "text": ["You are immune to poison damage and the poisoned condition."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Abyssal, and Draconic."]
            }],
            "species": "Monsterous"
        }
    },
    "Planer": {
        "Aasimar": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Aasimar)",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Dungeon Master's Guide",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your celestial heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of grey."]
            }, {
                "name": "Celestial Resistance",
                "text": ["You have resistance to necrotic and radiant damage."]
            }, {
                "name": "Celestial Legacy",
                "text": ["You know the light cantrip. Once you reach 3rd level, you can cast the lesser restoration spell once with this trait, and you regain the ability to do so when you finish a long rest. Once you reach 5th level, you can cast the daylight spell once with this trait as a 3rd-level spell, and you regain the ability to do so when you finish a long rest. Charisma is your spellcasting ability for these spells."]
            }, {
                "name": "Language",
                "text": ["You can speak, read, and write Common and Celestial."]
            }],
            "species": "Planer"
        },
        "Fallen Aasimar": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Fallen Aasimar",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Darkvision",
                "text": ["Blessed with a radiant soul, your vision can easily cut through darkness. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Celestial Resistance",
                "text": ["You have resistance to necrotic damage and radiant damage."]
            }, {
                "name": "Healing Hands",
                "text": ["As an action, you can touch a creature and cause it to regain a number of hit points equal to your level. Once you use this trait, you can't use it again until you finish a long rest."]
            }, {
                "name": "Light Bearer",
                "text": ["You know the light cantrip. Charisma is your spellcasting ability for it."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Celestial."]
            }, {
                "name": "Necrotic Shroud",
                "text": ["Starting at 3rd level, you can use your action to unleash the divine energy within yourself, causing your eyes to turn into pools of darkness and two skeletal, ghostly, flightless wings to sprout from your back. The instant you transform, other creatures within 10 feet of you that can see you must succed on a Charisma saving throw (DC 8 + your proficiency bonus + your Charisma modifier) or become frightened of you until the end of your next turn.", "Your transformation lasts for 1 minute or until you end it as a bonus action. During it,  once on each of your turns, you can deal extra necrotic damage to one target when you deal damage to it with an attack or a spell. The extra necrotic damage equals your level.", "Once you use this trait, you can't use it again until you finish a long rest."]
            }],
            "species": "Planer"
        },
        "Protector Aasimar": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Protector Aasimar",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Darkvision",
                "text": ["Blessed with a radiant soul, your vision can easily cut through darkness. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Celestial Resistance",
                "text": ["You have resistance to necrotic damage and radiant damage."]
            }, {
                "name": "Healing Hands",
                "text": ["As an action, you can touch a creature and cause it to regain a number of hit points equal to your level. Once you use this trait, you can't use it again until you finish a long rest."]
            }, {
                "name": "Light Bearer",
                "text": ["You know the light cantrip. Charisma is your spellcasting ability for it."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Celestial."]
            }, {
                "name": "Radiant Soul",
                "text": ["Starting at 3rd level, you can use your action to unleash the divine energy within yourself, causing your eyes to glimmer and two luminous, incorporeal wings to sprout from your back.", "Your transformation lasts for 1 minute or until you end it as a bonus action. During it, you have a flying speed of 30 feet, and once on each of your turns, you can deal extra radiant damage to one target when you deal damage to it with an attack or a spell. The extra radiant damage equals your level.", "Once you use this trait, you can't use it again until you finish a long rest."]
            }],
            "species": "Planer"
        },
        "Scourge Aasimar": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Scourge Aasimar",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Volo's Guide to Monsters",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "",
            "traits": [{
                "name": "Darkvision",
                "text": ["Blessed with a radiant soul, your vision can easily cut through darkness. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Celestial Resistance",
                "text": ["You have resistance to necrotic damage and radiant damage."]
            }, {
                "name": "Healing Hands",
                "text": ["As an action, you can touch a creature and cause it to regain a number of hit points equal to your level. Once you use this trait, you can't use it again until you finish a long rest."]
            }, {
                "name": "Light Bearer",
                "text": ["You know the light cantrip. Charisma is your spellcasting ability for it."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Celestial."]
            }, {
                "name": "Radiant Consumption",
                "text": ["Starting at 3rd level, you can use your action to unleash the divine energy within yourself, causing a searing light to radiate from you, pour out of your eyes and mouth, and threaten to char you.", "Your transformation lasts for 1 minute or until you end it as a bonus action. During it, you shed bright light in a 10-foot radius and dim light for an additional 10 feet, and at the end of each of your turns, you and each creature within 10 feet of you take radiant damage equal to half your level (rounded up). In addition, once on each of your turns, you can deal extra radiant damage to one target when you deal damage to it with an attack or a spell. The extra radiant damage equals your level.", "Once you use this trait, you can't use it again until you finish a long rest."]
            }],
            "species": "Planer"
        },
        "Aetherborn": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Aetherborn",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Kaladesh",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Intimidation",
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Born of Aether",
                "text": ["You have resistance to necrotic damage."]
            }, {
                "name": "Menacing",
                "text": ["You have proficiency in the Intimidation skill."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and two other languages of your choice."]
            }],
            "species": "Planer"
        },
        "Air Genasi": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Air Genasi",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Elemental Evil Player's Companion",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Unending Breath",
                "text": ["You can hold your breath indefinitely while you're not incapacitated."]
            }, {
                "name": "Mingle with the Wind",
                "text": ["You can cast the levitate spell once with this trait, requiring no material components, and you regain the ability to cast it this way when you finish a long rest. Constitution is your spellcasting ability for this spell."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Primordial. Primordial is a guttural language, filled with harsh syllables and hard consonants."]
            }],
            "species": "Planer"
        },
        "Earth Genasi": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Earth Genasi",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Elemental Evil Player's Companion",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Earth Walk",
                "text": ["You can move across difficult terrain made of earth or stone without expending extra movement."]
            }, {
                "name": "Merge with Stone",
                "text": ["You can cast the pass without trace spell once with this trait, requiring no material components, and you regain the ability to cast it this way when you finish a long rest. Constitution is your spellcasting ability for this spell."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Primordial. Primordial is a guttural language, filled with harsh syllables and hard consonants."]
            }],
            "species": "Planer"
        },
        "Fire Genasi": {
            "stats": {
                "INT": 1,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Fire Genasi",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Elemental Evil Player's Companion",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. Your ties to the Elemental Plane of Fire make your darkvision unusual: everything you see in darkness is in a shade of red."]
            }, {
                "name": "Fire Resistance",
                "text": ["You have resistance to fire damage."]
            }, {
                "name": "Reach to the Blaze",
                "text": ["You know the produce flame cantrip. Once you reach 3rd level, you can cast the burning hands spell once with this trait as a 1st-level spell, and you regain the ability to cast it this way when you finish a long rest. Constitution is your spellcasting ability for these spells."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Primordial. Primordial is a guttural language, filled with harsh syllables and hard consonants."]
            }],
            "species": "Planer"
        },
        "Water Genasi": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Water Genasi",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Elemental Evil Player's Companion",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Acid Resistance",
                "text": ["You have resistance to acid damage."]
            }, {
                "name": "Amphibious",
                "text": ["You can breathe air and water."]
            }, {
                "name": "Swim",
                "text": ["You have a swimming speed of 30 feet."]
            }, {
                "name": "Call to the Wave",
                "text": ["You know the shape water cantrip. When you reach 3rd level, you can cast the create or destroy water spell as a 2nd-level spell once with this trait, and you regain the ability to cast it this way when you finish a long rest. Constitution is your spellcasting ability for these spells."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Primordial. Primordial is a guttural language, filled with harsh syllables and hard consonants."]
            }],
            "species": "Planer"
        },
        "Khenra": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Khenra",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "35",
            "size": "M",
            "source": "Plane Shift Amonkhet",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Khenra Weapon Training",
                "text": ["You have proficiency with the khopesh (longsword), spear, and javelin."]
            }, {
                "name": "Khenra Twins.",
                "text": ["If your twin is alive and you can see your twin, whenever you roll a 1 on an attack roll, ability check, or saving throw, you can reroll the die and must use the new roll. If your twin is dead (or if you were born without a twin), you can't be frightened."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Khenra."]
            }],
            "species": "Planer"
        },
        "Kor": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Kor",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Acrobaics, Athletics",
            "traits": [{
                "name": "Brave",
                "text": ["You have advantage on saving throws against being frightened."]
            }, {
                "name": "Climbing",
                "text": ["You also have a climbing speed of 30 feet as long as you are not encumbered or wearing heavy armor."]
            }, {
                "name": "Kor Climbing",
                "text": ["You have proficiency in the Athletics and Acrobatics skills."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, and communicate in the silent speech of the Kor."]
            }, {
                "name": "Lucky",
                "text": ["When you roll a 1 on the d20 for an attack roll, ability check, or saving throw, you can reroll the die and must use the new roll."]
            }],
            "species": "Planer"
        },
        "Abyssal Tiefling": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Abyssal Tiefling",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: That Old Black Magic",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your infernal heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Abyssal Arcana",
                "text": ["Each time you finish a long rest, you gain the ability to cast cantrips and spells randomly determined from a short list. At 1st level, you can cast a cantrip. When you reach 3rd level, you can also cast a 1st-level spell. At 5th level, you can cast a 2nd-level spell.", "You can cast a spell gained from this trait only once until you complete your next long rest. You can cast a cantrip gained from this trait at will, as normal. For 1st-level spells whose effect changes if cast using a spell slot of 2nd level or higher, you cast the spell as if using a 2nd-level slot. Spells of 2nd level are cast as if using a 2nd-level slot", "At the end of each long rest, you lose the cantrips and spells previously granted by this feature, even if you did not cast them. You replace those cantrips and spells by rolling for new ones on the Abyssal Arcana Spells table. Roll separately for each cantrip and spell. If you roll the same spell or cantrip you gained at the end of your previous long rest, roll again until you get a different result.", "", "d6 ? 1st level ? 3rd level ? 5th level:", "1 ? dancing lights ? burning hands ? alter self", "2 ? true strike ? charm person ? darkness", "3 ? light ? magic missile ? invisibility", "4 ? message ? cure wounds ? levitate", "5 ? spare the dying ? Tasha's hideous laughter ? mirror image", "6 ? prestidigitation ? thunderwave ? spider climb"]
            }, {
                "name": "Abyssal Fortitude",
                "text": ["Your hit point maximum increases by half your level (minimum 1)"],
                "modifier": "Hit Points +1"
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Abyssal."]
            }],
            "species": "Planer"
        },
        "Infernal Tiefling": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Infernal Tiefling",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your infernal heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Hellish Resistance",
                "text": ["You have resistance to fire damage."]
            }, {
                "name": "Infernal Legacy",
                "text": ["You know the thaumaturgy cantrip. Once you reach 3rd level, you can cast the hellish rebuke spell as a 2nd-level spell; you must finish a long rest in order to cast the spell again using this trait. Once you reach 5th level, you can also cast the darkness spell; you must finish a long rest in order to cast the spell again using this trait. Charisma is your spellcasting ability for these spells."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Infernal."]
            }, {
                "name": "Feral (Variant)",
                "text": ["Your Intelligence score increases by 1, and your Dexterity score increases by 2. This replaces the Ability Score Increase trait."]
            }, {
                "name": "Variant Features (Choose 1)",
                "text": ["Devil's Tongue.", "You know the vicious mockery cantrip. When your reach 3rd level, you can cast the charm person spell as a 2nd-level spell once with this trait. When you reach 5th level, you can cast the enthrall spell once with this trait. You must finish a long rest to cast these spells once again with this trait. Charisma is your spellcasting ability for them. This trait replaces the Infernal Legacy trait.", null, "Hellfire.", "Once you reach 3rd level, you can cast the burning hands spell once per day as a 2nd-level spell. This trait replaces the hellish rebuke spell of the Infernal Legacy trait.", null, "Winged.", "You have bat-like wings sprouting form on your shoulder blades. You have a flying speed of 30 feet. This trait replaces the Infernal Legacy trait."]
            }, {
                "name": "Appearance (Variant)",
                "text": ["Your tiefling might not look like other tieflings. Rather than having the physical characteristics described in the Player's Handbook, choose 1d4 + 1 of the following features: small horns; fangs or sharp teeth; a forked tongue; catlike eyes; six fingers on each hand; goatlike legs; cloven hoofs; a forked tail; leathery or scaly skin; red or dark blue skin; cast no shadow or reflection; exude a smell of brimstone"]
            }],
            "species": "Planer"
        },
        "Vedalken": {
            "stats": {
                "INT": 2,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Vedalken",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Kaladesh",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Vedalken Cunning",
                "text": ["You have advantage on all Intelligence, Wisdom, and Charisma saving throws against magic"]
            }, {
                "name": "Aether Lore",
                "text": ["Whenever you make an Intelligence (History) check related to magic items or aether-powered technological devices, you can add twice your proficiency bonus, instead of any proficiency bonus you normally apply."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Vedalken. The Vedalken language is renowned for its technical treatises and its catalogs of knowledge about the natural world and the aether that pervades it."]
            }],
            "species": "Planer"
        }
    },
    "Halfbreeds": {
        "Dragonborn": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Dragonborn",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Draconic Ancestry",
                "text": ["You have draconic ancestry. Choose one type of dragon from the Draconic Ancestry table. Your breath weapon and damage resistance are determined by the dragon type, as shown in the table. (Player's Handbook p. 34)"]
            }, {
                "name": "Breath Weapon",
                "text": ["You can use your action to exhale destructive energy. Your draconic ancestry determines the size, shape, and damage type of the exhalation.", null, "When you use your breath weapon, each creature in the area of the exhalation must make a saving throw, the type of which is determined by your draconic ancestry. The DC for this saving throw equals 8 + your Constitution modifier + your proficiency bonus. A creature takes 2d6 damage on a failed save, and half as much damage on a successful one. The damage increases to 3d6 at 6th level, 4d6 at 11th level, and 5d6 at 16th level.", null, "After you use your breath weapon, you can't use it again until you complete a short or long rest."]
            }, {
                "name": "Damage Resistance",
                "text": ["You have resistance to the damage type associated with your draconic ancestry."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Draconic. Draconic is thought to be one of the oldest languages and is often used in the study of magic. The language sounds harsh to most other creatures and includes numerous hard consonants and sibilants."]
            }],
            "species": "Halfbreeds"
        },
        "Changeling": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Changeling",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Unearthed Arcana: Eberron",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Deception",
            "traits": [{
                "name": "Duplicity",
                "text": ["You gain proficiency in the Deception skill."]
            }, {
                "name": "Shapechanger",
                "text": ["As an action, you can polymorph into any humanoid of your size that you have seen, or back into your true form. However, your equipment does not change with you. If you die, you revert to your natural appearance."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and two other languages of your choice."]
            }],
            "species": "Halfbreeds"
        },
        "Half-Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Half-Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Two different ability scores of your choice increase by 1."]
            }, {
                "name": "Darkvision",
                "text": ["Thanks to your elf blood, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Skill Versatility",
                "text": ["You gain proficiency in two skills of your choice."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice."]
            }],
            "species": "Halfbreeds"
        },
        "Aquatic Half-Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Aquatic Half-Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Sword Coast Adventurer's Guide",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Two different ability scores of your choice increase by 1."]
            }, {
                "name": "Darkvision",
                "text": ["Thanks to your elf blood, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Variant Feature (Choose 1)",
                "text": ["Keen Senses", "You have proficiency in the Perception skill", null, "Swim", "You gain a swimming speed of 30.", null]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice."]
            }],
            "species": "Halfbreeds"
        },
        "Drow Half-Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Drow Half-Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Sword Coast Adventurer's Guide",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Two different ability scores of your choice increase by 1."]
            }, {
                "name": "Darkvision",
                "text": ["Thanks to your elf blood, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Variant Feature (Choose 1)",
                "text": ["Keen Senses", "You have proficiency in the Perception skill", null, "Drow Magic", "You know the dancing lights cantrip. When you reach 3rd level, you can cast the faerie fire spell once per day; you must finish a long rest in order to cast the spell again using this trait. When you reach 5th level, you can also cast the darkness spell once per day; you must finish a long rest in order to cast the spell again using this trait. Charisma is your spellcasting ability for these spells."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice."]
            }],
            "species": "Halfbreeds"
        },
        "Moon/Sun Half-Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Moon/Sun Half-Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Sword Coast Adventurer's Guide",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Two different ability scores of your choice increase by 1."]
            }, {
                "name": "Darkvision",
                "text": ["Thanks to your elf blood, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Variant Feature (Choose 1)",
                "text": ["Keen Senses", "You have proficiency in the Perception skill", null, "Elf Weapon Training", "You have proficiency with the longsword, shortsword, shortbow, and longbow.", null, "Cantrip", "You know one cantrip of your choice from the wizard spell list. Intelligence is your spellcasting ability for it."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice."]
            }],
            "species": "Halfbreeds"
        },
        "Wood Half-Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Wood Half-Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Sword Coast Adventurer's Guide",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Two different ability scores of your choice increase by 1."]
            }, {
                "name": "Darkvision",
                "text": ["Thanks to your elf blood, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Variant Feature (Choose 1)",
                "text": ["Keen Senses", "You have proficiency in the Perception skill", null, "Elf Weapon Training", "You have proficiency with the longsword, shortsword, shortbow, and longbow.", null, "Fleet of Foot", "Your base walking speed increases to 35 feet.", null, "Mask of the Wild", "You can attempt to hide even when you are only lightly obscured by foliage, heavy rain, falling snow, mist, and other natural phenomena."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice."]
            }],
            "species": "Halfbreeds"
        },
        "Half-Orc": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Half-Orc",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "proficiency": "Intimidation",
            "traits": [{
                "name": "Darkvision",
                "text": ["Thanks to your orc blood, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Menacing",
                "text": ["You gain proficiency in the Intimidation skill."]
            }, {
                "name": "Relentless Endurance",
                "text": ["When you are reduced to 0 hit points but not killed outright, you can drop to 1 hit point instead. You can't use this feature again until you finish a long rest."]
            }, {
                "name": "Savage Attacks",
                "text": ["When you score a critical hit with a melee weapon attack, you can roll one of the weapon's damage dice one additional time and add it to the extra damage of the critical hit."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Orc. Orc is a harsh, grating language with hard consonants. It has no script of its own but is written in the Dwarvish script."]
            }],
            "species": "Halfbreeds"
        }
    },
    "Dwarven": {
        "Duergar": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Duergar",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "M",
            "source": "Sword Coast Adventurer's Guide",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Speed",
                "text": ["Your speed is not reduced by wearing heavy armor."]
            }, {
                "name": "Superior Darkvision",
                "text": ["Accustomed to life underground, you have superior vision in dark and dim conditions. You can see in dim light within 120 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Duergar Resilience",
                "text": ["You have advantage on saving throws against poison, and you have resistance against poison damage. You also have advantage on saving throws against illusions and against being charmed or paralyzed."]
            }, {
                "name": "Dwarven Combat Training",
                "text": ["You have proficiency with the battleaxe, handaxe, light hammer, and warhammer."]
            }, {
                "name": "Tool Proficiency",
                "text": ["You gain proficiency with the artisan's tools of your choice: smith's tools, brewer's supplies, or mason's tools."]
            }, {
                "name": "Stonecunning",
                "text": ["Whenever you make an Intelligence (History) check related to the origin of stonework, you are considered proficient in the History skill and add double your proficiency bonus to the check, instead of your normal proficiency bonus."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Dwarvish, and Undercommon."]
            }, {
                "name": "Duergar Magic",
                "text": ["When you reach 3rd level, you can cast the Enlarge/Reduce spell on yourself once with this trait, using only the spell's enlarge option. When reach 5th level, you can cast the Invisibility spell on yourself once with this trait. You don't need material components for either spell, and you can't cast them while you're in direct sunlight, although sunlight has no effect on them once cast. You regain the ability to cast these spells with this trait when you finish a long rest. Intelligence is your spellcasting ability for these spells."]
            }, {
                "name": "Sunlight Sensitivity",
                "text": ["You have disadvantage on attack rolls and Wisdom (Perception) checks that rely on sight when you, the target of your attack, or whatever you are trying to perceive is in direct sunlight."]
            }],
            "species": "Dwarven"
        },
        "Hill Dwarf": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Hill Dwarf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Speed",
                "text": ["Your speed is not reduced by wearing heavy armor."]
            }, {
                "name": "Darkvision",
                "text": ["Accustomed to life underground, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Dwarven Resilience",
                "text": ["You have advantage on saving throws against poison, and you have resistance against poison damage."]
            }, {
                "name": "Dwarven Combat Training",
                "text": ["You have proficiency with the battleaxe, handaxe, light hammer, and warhammer."]
            }, {
                "name": "Tool Proficiency",
                "text": ["You gain proficiency with the artisan's tools of your choice: smith's tools, brewer's supplies, or mason's tools."]
            }, {
                "name": "Stonecunning",
                "text": ["Whenever you make an Intelligence (History) check related to the origin of stonework, you are considered proficient in the History skill and add double your proficiency bonus to the check, instead of your normal proficiency bonus."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Dwarvish. Dwarvish is full of hard consonants and guttural sounds, and those characteristics spill over into whatever other language a dwarf might speak."]
            }, {
                "name": "Dwarven Toughness",
                "text": ["Your hit point maximum increases by 1, and it increases by 1 every time you gain a level."]
            }],
            "species": "Dwarven"
        },
        "Mountain Dwarf": {
            "stats": {
                "INT": 0,
                "CON": 2,
                "DEX": 0,
                "STR": 2,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Mountain Dwarf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Speed",
                "text": ["Your speed is not reduced by wearing heavy armor."]
            }, {
                "name": "Darkvision",
                "text": ["Accustomed to life underground, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Dwarven Resilience",
                "text": ["You have advantage on saving throws against poison, and you have resistance against poison damage."]
            }, {
                "name": "Dwarven Combat Training",
                "text": ["You have proficiency with the battleaxe, handaxe, light hammer, and warhammer."]
            }, {
                "name": "Tool Proficiency",
                "text": ["You gain proficiency with the artisan's tools of your choice: smith's tools, brewer's supplies, or mason's tools."]
            }, {
                "name": "Stonecunning",
                "text": ["Whenever you make an Intelligence (History) check related to the origin of stonework, you are considered proficient in the History skill and add double your proficiency bonus to the check, instead of your normal proficiency bonus."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Dwarvish. Dwarvish is full of hard consonants and guttural sounds, and those characteristics spill over into whatever other language a dwarf might speak."]
            }, {
                "name": "Dwarven Armor Training",
                "text": ["You have proficiency with light and medium armor."]
            }],
            "species": "Dwarven"
        }
    },
    "Elven": {
        "Elf": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }, {
                "name": "Cantrip",
                "text": ["You know one cantrip of your choice from the wizard spell list. Intelligence is your spellcasting ability for it."]
            }],
            "species": "Elven"
        },
        "Bishatar/Tirahar Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "80",
            "gender": 60,
            "parents": {
                "no": "0",
                "age": "5d10+30"
            },
            "name": "Bishatar/Tirahar Elf",
            "apprentice": {
                "age": "5d10+10",
                "no": "1d2",
                "livingwith": "40"
            },
            "children": {
                "hasthem": "70",
                "no": "1d4-1",
                "age": "5d10+90"
            },
            "speed": "35",
            "size": "M",
            "source": "Plane Shift Kaladesh",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Fleet of Foot",
                "text": ["Your ground speed increases to 35 feet."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Mask of the Wild",
                "text": ["You can attempt to hide even when you are only lightly obscured by foliage, heavy rain, falling snow, mist, and other natural phenomena."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }],
            "species": "Elven"
        },
        "Star Elf": {
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "35",
            "size": "M",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "apprentice": {
                "age": "3d4",
                "livingwith": "70",
                "no": "1d2"
            },
            "gender": 75,
            "married": "70",
            "stats": {
                "WIS": 0,
                "CHR": 1,
                "DEX": 2,
                "STR": 0,
                "INT": 0,
                "CON": 0
            },
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Star Elf",
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }, {
                "name": "Cantrip",
                "text": ["You know one cantrip of your choice from the wizard spell list. Intelligence is your spellcasting ability for it."]
            }],
            "species": "Elven"
        },
        "Drow": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 40,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Drow",
            "apprentice": {
                "age": "3d4",
                "livingwith": "70",
                "no": "1d2"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Superior Darkvision",
                "text": ["Accustomed to the depths of the Underdark, you have superior vision in dark and dim conditions. You can see in dim light within 120 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Sunlight Sensitivity",
                "text": ["You have disadvantage on attack rolls and on Wisdom (Perception) checks that rely on sight when you, the target of your attack, or whatever you are trying to perceive is in direct sunlight."]
            }, {
                "name": "Drow Magic",
                "text": ["You know the dancing lights cantrip. When you reach 3rd level, you can cast the faerie fire spell once per day; you must finish a long rest in order to cast the spell again using this trait. When you reach 5th level, you can also cast the darkness spell once per day; you must finish a long rest in order to cast the spell again using this trait. Charisma is your spellcasting ability for these spells."]
            }, {
                "name": "Drow Weapon Training",
                "text": ["You have proficiency with rapiers, shortswords, and hand crossbows."]
            }],
            "species": "Elven"
        },
        "Eladrin Elf": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Eladrin Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Dungeon Master's Guide",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }, {
                "name": "Fey Step",
                "text": ["You can cast the misty step spell once using this trait. You regain the ability to do so when you finish a short or long rest."]
            }],
            "species": "Elven"
        },
        "High  Elf": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "High  Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Elvish, and one extra language of your choice. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }, {
                "name": "Cantrip",
                "text": ["You know one cantrip of your choice from the wizard spell list. Intelligence is your spellcasting ability for it."]
            }],
            "species": "Elven"
        },
        "Joraga Nation Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 2
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Joraga Nation Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "35",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Fleet of Foot",
                "text": ["Your ground speed increases to 35 feet."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Mask of the Wild",
                "text": ["You can attempt to hide even when you are only lightly obscured by foliage, heavy rain, falling snow, mist, and other natural phenomena."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }],
            "species": "Elven"
        },
        "Mul Daya Nation Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 2
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Mul Daya Nation Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Mul Daya Magic",
                "text": ["You know the chill touch cantrip. When you reach 3rd level, you can cast the hex spell once with this trait and regain the ability to do so when you finish a long rest. When you reach 5th level, you can cast the darkness spell once with this trait and regain the ability to do so when you finish a long rest. Wisdom is your spellcasting ability for these spells."]
            }, {
                "name": "Superior Darkvision",
                "text": ["Your Darkvision has a radius of 120 feet."]
            }, {
                "name": "Sunlight Sensitivity",
                "text": ["You have disadvantage on attack rolls and on Wisdom (Perception) checks that rely on sight when you, the target of your attack, or whatever you are trying to perceive is in direct sunlight."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }],
            "species": "Elven"
        },
        "Tajuru Nation Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 2
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Tajuru Nation Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception, select two others",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Skill Versatility",
                "text": ["You have proficiency with any combination of two other skills or tools of your choice."]
            }],
            "species": "Elven"
        },
        "Vadahar Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Vadahar Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Kaladesh",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }, {
                "name": "Cantrip",
                "text": ["You know one cantrip of your choice from the wizard spell list. Intelligence is your spellcasting ability for it."]
            }, {
                "name": "Extra Language",
                "text": ["You can speak, read, and write one extra language of your choosing."]
            }],
            "species": "Elven"
        },
        "Wood Elf": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Wood Elf",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "35",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 110,
                "maxage": 750
            },
            "proficiency": "Perception",
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Keen Senses",
                "text": ["You have proficiency in the Perception skill."]
            }, {
                "name": "Fey Ancestry",
                "text": ["You have advantage on saving throws against being charmed, and magic can't put you to sleep."]
            }, {
                "name": "Trance",
                "text": ["Elves don't need to sleep. Instead, they meditate deeply, remaining semiconscious, for 4 hours a day. (The Common word for such meditation is \"trance.\") While meditating, you can dream after a fashion; such dreams are actually mental exercises that have become reflexive through years of practice. After resting in this way, you gain the same benefit that a human does from 8 hours of sleep."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Elvish. Elvish is fluid, with subtle intonations and intricate grammar. Elven literature is rich and varied, and their songs and poems are famous among other races. Many bards learn their language so they can add Elvish ballads to their repertoires."]
            }, {
                "name": "Elf Weapon Training",
                "text": ["You have proficiency with the longsword, shortsword, shortbow, and longbow."]
            }, {
                "name": "Fleet of Foot",
                "text": ["Your base walking speed increases to 35 feet."]
            }, {
                "name": "Mask of the Wild",
                "text": ["You can attempt to hide even when you are only lightly obscured by foliage, heavy rain, falling snow, mist, and other natural phenomena."]
            }],
            "species": "Elven"
        }
    },
    "Gnome": {
        "Deep Gnome": {
            "stats": {
                "INT": 2,
                "CON": 0,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Deep Gnome",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Elemental Evil Player's Companion",
            "age": {
                "adulthood": 40,
                "maxage": 400
            },
            "traits": [{
                "name": "Superior Darkvision",
                "text": ["Accustomed to life underground, you have superior vision in dark and dim conditions. You can see in dim light within 120 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Gnome Cunning",
                "text": ["You have advantage on all Intelligence, Wisdom, and Charisma saving throws against magic."]
            }, {
                "name": "Stone Camouflage",
                "text": ["You have advantage on Dexterity (stealth) checks to hide in rocky terrain."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common, Gnomish, and Undercommon. The svirfneblin dialect is more guttural than surface Gnomish, and most svirfneblin know only a little bit of Common, but those who deal with outsiders (and that includes you as an adventurer) pick up enough Common to get by in other lands."]
            }],
            "species": "Gnome"
        },
        "Forest Gnome": {
            "stats": {
                "INT": 2,
                "CON": 0,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Forest Gnome",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 40,
                "maxage": 400
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to life underground, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Gnome Cunning",
                "text": ["You have advantage on all Intelligence, Wisdom, and Charisma saving throws against magic."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Gnomish. The Gnomish language, which uses the Dwarvish script, is renowned for its technical treatises and its catalogs of knowledge about the natural world."]
            }, {
                "name": "Natural Illusionist",
                "text": ["You know the minor illusion cantrip. Intelligence is your spellcasting ability for it."]
            }, {
                "name": "Speak with Small Beasts",
                "text": ["Through sounds and gestures, you can communicate simple ideas with Small or smaller beasts. Forest gnomes love animals and often keep squirrels, badgers, rabbits, moles, woodpeckers, and other creatures as beloved pets."]
            }],
            "species": "Gnome"
        },
        "Rock Gnome": {
            "stats": {
                "INT": 2,
                "CON": 1,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Rock Gnome",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 40,
                "maxage": 400
            },
            "traits": [{
                "name": "Darkvision",
                "text": ["Accustomed to life underground, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Gnome Cunning",
                "text": ["You have advantage on all Intelligence, Wisdom, and Charisma saving throws against magic."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Gnomish. The Gnomish language, which uses the Dwarvish script, is renowned for its technical treatises and its catalogs of knowledge about the natural world."]
            }, {
                "name": "Artificer's Lore",
                "text": ["Whenever you make an Intelligence (History) check related to magic items, alchemical objects, or technological devices, you can add twice your proficiency bonus, instead of any proficiency bonus you normally apply."]
            }, {
                "name": "Tinker",
                "text": ["You have proficiency with artisan's tools (tinker's tools). Using those tools, you can spend 1 hour and 10 gp worth of materials to construct a Tiny clockwork device (AC 5, 1 hp). The device ceases to function after 24 hours (unless you spend 1 hour repairing it to keep the device functioning), or when you use your action to dismantle it; at that time, you can reclaim the materials used to create it. You can have up to three such devices active at a time.", null, "When you create a device, choose one of the following options:", null, "Clockwork Toy. This toy is a clockwork animal, monster, or person, such as a frog, mouse, bird, dragon, or soldier. When placed on the ground, the toy moves 5 feet across the ground on each of your turns in a random direction. It makes noises as appropriate to the creature it represents.", null, "Fire Starter. The device produces a miniature flame, which you can use to light a candle, torch, or campfire. Using the device requires your action.", null, "Music Box. When opened, this music box plays a single song at a moderate volume. The box stops playing when it reaches the song's end or when it is closed."]
            }],
            "species": "Gnome"
        },
        "WhisperGnome": {
            "married": "70",
            "stats": {
                "CHR": 0,
                "WIS": 0,
                "CON": 0,
                "INT": 2,
                "STR": 0,
                "DEX": 1
            },
            "gender": 75,
            "name": "WhisperGnome",
            "parents": {
                "no": "1d3-1",
                "age": "3d4+25"
            },
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "age": {
                "adulthood": 40,
                "maxage": 400
            },
            "children": {
                "no": "1d3",
                "hasthem": "50",
                "age": "2d10+10"
            },
            "speed": "30",
            "size": "M",
            "source": "Elemental Evil Player's Companion",
            "proficiency": "Athletics",
            "traits": [{
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Gnomish."]
            }],
            "species": "Gnome"
        }
    },
    "Halfling": {
        "Ghostwise Halfling": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Ghostwise Halfling",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Sword Coast Adventurer's Guide",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Lucky",
                "text": ["When you roll a 1 on an attack roll, ability check, or saving throw, you can reroll the die and must use the new roll."]
            }, {
                "name": "Brave",
                "text": ["You have advantage on saving throws against being frightened."]
            }, {
                "name": "Halfling Nimbleness",
                "text": ["You can move through the space of any creature that is of a size larger than yours."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Halfling. The Halfling language isn't secret, but halflings are loath to share it with others. They write very little, so they don't have a rich body of literature. Their oral tradition, however, is very strong. Almost all halflings speak Common to converse with the people in whose lands they dwell or through which they are traveling."]
            }, {
                "name": "Silent Speech",
                "text": ["You can speak telepathically to any creature within 30 feet of you. The creature understands you only if the two of you share a language. You can speak telepathically in this way to one creature at a time."]
            }],
            "species": "Halfling"
        },
        "Lightfoot Halfling": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Lightfoot Halfling",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Lucky",
                "text": ["When you roll a 1 on an attack roll, ability check, or saving throw, you can reroll the die and must use the new roll."]
            }, {
                "name": "Brave",
                "text": ["You have advantage on saving throws against being frightened."]
            }, {
                "name": "Halfling Nimbleness",
                "text": ["You can move through the space of any creature that is of a size larger than yours."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Halfling. The Halfling language isn't secret, but halflings are loath to share it with others. They write very little, so they don't have a rich body of literature. Their oral tradition, however, is very strong. Almost all halflings speak Common to converse with the people in whose lands they dwell or through which they are traveling."]
            }, {
                "name": "Naturally Stealthy",
                "text": ["You can attempt to hide even when you are obscured only by a creature that is at least one size larger than you."]
            }],
            "species": "Halfling"
        },
        "Stout Halfling": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 2,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Stout Halfling",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "25",
            "size": "S",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Lucky",
                "text": ["When you roll a 1 on an attack roll, ability check, or saving throw, you can reroll the die and must use the new roll."]
            }, {
                "name": "Brave",
                "text": ["You have advantage on saving throws against being frightened."]
            }, {
                "name": "Halfling Nimbleness",
                "text": ["You can move through the space of any creature that is of a size larger than yours."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Halfling. The Halfling language isn't secret, but halflings are loath to share it with others. They write very little, so they don't have a rich body of literature. Their oral tradition, however, is very strong. Almost all halflings speak Common to converse with the people in whose lands they dwell or through which they are traveling."]
            }, {
                "name": "Stout Resilience",
                "text": ["You have advantage on saving throws against poison, and you have resistance against poison damage."]
            }],
            "species": "Halfling"
        }
    },
    "Human": {
        "Human": {
            "stats": {
                "INT": 1,
                "CON": 1,
                "DEX": 1,
                "STR": 1,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Human",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 15,
                "maxage": 90
            },
            "traits": [{
                "name": "Languages",
                "text": ["You can speak, read, and write Common and one extra language of your choice. Humans typically learn the languages of other peoples they deal with, including obscure dialects. They are fond of sprinkling their speech with words borrowed from other tongues: Orc curses, Elvish musical expressions, Dwarvish military phrases, and so on."]
            }],
            "species": "Human"
        },
        "Amonkhet Human": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Amonkhet Human",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 15,
                "maxage": 90
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Two different ability scores of your choice increase by 1."]
            }, {
                "name": "Skills",
                "text": ["You gain proficiency in one skill of your choice."]
            }, {
                "name": "Feat",
                "text": ["You gain one feat of your choice."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and one extra language of your choice."]
            }],
            "species": "Human"
        },
        "Gavony Human": {
            "stats": {
                "INT": 1,
                "CON": 1,
                "DEX": 1,
                "STR": 1,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Gavony Human",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Innistrad",
            "age": {
                "adulthood": 15,
                "maxage": 90
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Your ability scores each increase by 1."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and one extra language of your choice."]
            }],
            "species": "Human"
        },
        "Kessig Human": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 1,
                "STR": 0,
                "CHR": 0,
                "WIS": 1
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Kessig Human",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Innistrad",
            "age": {
                "adulthood": 15,
                "maxage": 90
            },
            "traits": [{
                "name": "Forest Folk",
                "text": ["You have proficiency in the Survival skill."]
            }, {
                "name": "Fleet of Foot",
                "text": ["Your base walking speed is 40 feet."]
            }, {
                "name": "Sure-footed",
                "text": ["When you use the Dash action, difficult terrain doesn't cost you extra movement on that turn."]
            }, {
                "name": "Spring Attack",
                "text": ["When you make a melee attack against a creature, you don't provoke opportunity attacks from that creature for the rest of your turn, whether you hit or not."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and one extra language of your choice."]
            }],
            "species": "Human"
        },
        "Nephalia Human": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Nephalia Human",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Innistrad",
            "age": {
                "adulthood": 15,
                "maxage": 90
            },
            "traits": [{
                "name": "Breadth of Knowledge",
                "text": ["You gain proficiency in any combination of four skills or with four tools of your choice."]
            }],
            "species": "Human"
        },
        "Stensia Human": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 1,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Stensia Human",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Innistrad",
            "age": {
                "adulthood": 15,
                "maxage": 90
            },
            "traits": [{
                "name": "Daunting",
                "text": ["You have proficiency in the Intimidation skill."]
            }, {
                "name": "Tough",
                "text": ["Your hit point maximum increases by 2, and it increases by 2 every time you gain a level."]
            }],
            "species": "Human"
        },
        "Human Variant": {
            "stats": {
                "INT": 0,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Human Variant",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Player's Handbook",
            "age": {
                "adulthood": 15,
                "maxage": 90
            },
            "traits": [{
                "name": "Ability Score Increase",
                "text": ["Two different ability scores of your choice increase by 1."]
            }, {
                "name": "Skills",
                "text": ["You gain proficiency in one skill of your choice."]
            }, {
                "name": "Feat",
                "text": ["You gain one feat of your choice."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and one extra language of your choice. Humans typically learn the languages of other peoples they deal with, including obscure dialects. They are fond of sprinkling their speech with words borrowed from other tongues: Orc curses, Elvish musical expressions, Dwarvish military phrases, and so on."]
            }],
            "species": "Human"
        }
    },
    "Undead": {
        "Revenant": {
            "stats": {
                "INT": 0,
                "CON": 1,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Revenant",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "",
            "size": "",
            "source": "Unearthed Arcana: Gothic Heroes",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Revenant Subrace",
                "text": ["Having met a cruel and undeserved end, you have returned to the realm of the living. As a revenant, you thirst for revenge against those who wronged you in life, or seek to complete a final, critical task you left unfinished.", "The revenant subrace can be applied to any race that has a subrace, and replaces that race's existing subrace options. Alternatively, you can apply this new subrace to a race without subrace options using the modification options provided below.", "Your DM might also allow you to take this subrace for a slain character. In that case, your character rises from the dead with its original subrace replaced (or with the necessary modifications made to its base traits), filled with a determination to seek vengeance or complete its mission."]
            }, {
                "name": "Racial Adjustments",
                "text": ["For races that don't have subrace options, taking on the revenant subrace means making changes to your character's base traits, as follows. (This playtest article provides options only for human and dragonborn characters. Because half-elves and half--orcs have no subrace options, they shouldn't be used with these revenant subrace rules.)", "Human Revenant. If you want to play a human revenant, modify the human's Ability Score Increase trait to the following: Two different ability scores of your choice increase by 1. If you use the variant human traits, remove the Skills trait and the Feat trait.", "Dragonborn Revenant. If you want to play a dragonborn revenant, modify the dragonborn's Ability Score Increase trait to the following: Your Strength score increases by 1, and your Charisma score increases by 1. Additionally, your Draconic Ancestry trait uses necrotic damage as its damage type, replacing the damage type that applies to your breath weapon and your damage resistance.", "Tiefling Revenant. A prior installment of Unearthed Arcana outlined two tiefling variants that make use of subraces. Use that article to make a tiefling revenant, replacing the subrace options with the revenant subrace options."]
            }, {
                "name": "Relentless Nature",
                "text": ["Your DM assigns a goal to you?typically, one related to your character's death. The goal must be a specific task you can complete, such as slaying an enemy or liberating an area and its people. Until you fulfill that goal, you gain the following benefits:", "? If you are below half your hit point maximum at the start of your turn, you regain 1 hit point. ", "? If you die, you return to life 24 hours after death. If your body is destroyed, you reform within 1 mile of the place of your death at a spot determined by the DM. If your equipment was also destroyed, you do not regain it.", "? You know the distance and direction between you and any creature involved in your goal, such as a person you seek vengeance against or someone you pledged to defend. This awareness fails if the creature is on another plane of existence. ", "When your goal is complete, you finally find rest. You die and cannot be restored to life."]
            }],
            "species": "Undead"
        },
        "Vampire": {
            "stats": {
                "INT": 1,
                "CON": 0,
                "DEX": 0,
                "STR": 0,
                "CHR": 0,
                "WIS": 0
            },
            "married": "70",
            "gender": 60,
            "parents": {
                "age": "3d4+25",
                "no": "1d3-1"
            },
            "name": "Vampire",
            "apprentice": {
                "no": "1d2",
                "livingwith": "70",
                "age": "3d4"
            },
            "children": {
                "age": "2d10+10",
                "hasthem": "50",
                "no": "1d3"
            },
            "speed": "30",
            "size": "M",
            "source": "Plane Shift Zendikar",
            "age": {
                "adulthood": 20,
                "maxage": 250
            },
            "traits": [{
                "name": "Blood Thirst",
                "text": ["You can drain blood and life energy from a willing creature, or one that is grappled by you, incapacitated, or restrained. Make a melee attack against the target. If you hit, you deal 1 piercing damage and 1d6 necrotic damage. The target's hit point maximum is reduced by an amount equal to the necrotic damage taken, and you regain hit points equal to that amount. The reduction lasts until the target finishes a long rest. The target dies if this effect reduces its hit point maximum to 0. A humanoid killed in this way becomes a null (see ?A Zendikar Bestiary?)."]
            }, {
                "name": "Darkvision",
                "text": ["Thanks to your heritage, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet of you as if it were bright light, and in darkness as if it were dim light. You can't discern color in darkness, only shades of gray."]
            }, {
                "name": "Languages",
                "text": ["You can speak, read, and write Common and Vampire."]
            }, {
                "name": "Vampiric Resistance",
                "text": ["You have resistance to necrotic damage."]
            }],
            "species": "Undead"
        }
    }
}; // END race_set

// Create a master object of all races.
for(var species in race_collection) {
    if (race_collection.hasOwnProperty(species)) {
        for(var race in race_collection[species]) {
            race_list[race] = species;
        }
    }
    
}