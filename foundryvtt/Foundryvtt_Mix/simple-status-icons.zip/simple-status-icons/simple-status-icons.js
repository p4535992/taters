const SimpleStatusIcons = (() => {
	const defineStatusIcons = function(data) {
		let path = "modules/simple-status-icons/png/";
		window.CONFIG.statusEffects = [
			{
				id: "dead",
				label: "Dead",
				icon: `${path}dead.png`
			},
			{
				id: "acid",
				label: "Acid",
				icon: `${path}acid.png`
			},
			{
				id: "bag",
				label: "Bag of Holding",
				icon: `${path}bag-of-holding.png`
			},
			{
				id: "bardic-inspiration",
				label: "Bardic Inspiration",
				icon: `${path}bardic-inspiration.png`
			},
			{
				id: "berserk",
				label: "Berserk",
				icon: `${path}berserk.png`
			},
			{
				id: "blessed",
				label: "Blessed",
				icon: `${path}blessed.png`
			},
			{
				id: "blinded",
				label: "Blinded",
				icon: `${path}blinded.png`
			},
			{
				id: "bloodied",
				label: "Bloodied",
				icon: `${path}bloodied.png`
			},
			{
				id: "broken",
				label: "Broken",
				icon: `${path}broken.png`
			},
			{
				id: "bubbled",
				label: "Bubbled",
				icon: `${path}bubbled.png`
			},
			{
				id: "chained",
				label: "Chained",
				icon: `${path}chained.png`
			},
			{
				id: "charmed",
				label: "Charmed",
				icon: `${path}charmed.png`
			},
			{
				id: "cloudwalk",
				label: "Cloudwalk",
				icon: `${path}cloudwalk.png`
			},
			{
				id: "crippled",
				label: "Crippled",
				icon: `${path}crippled.png`
			},
			{
				id: "deafened",
				label: "Deafened",
				icon: `${path}deafened.png`
			},
			{
				id: "disarmed",
				label: "Disarmed",
				icon: `${path}disarmed.png`
			},
			{
				id: "drunk",
				label: "Drunk",
				icon: `${path}drunk.png`
			},
			{
				id: "enflamed",
				label: "Enflamed",
				icon: `${path}enflamed.png`
			},
			{
				id: "entangled",
				label: "Entangled",
				icon: `${path}entangled.png`
			},
			{
				id: "exhausted",
				label: "Exhausted",
				icon: `${path}exhausted.png`
			},
			{
				id: "flying",
				label: "Flying",
				icon: `${path}flying.png`
			},
			{
				id: "frightened",
				label: "Frightened",
				icon: `${path}frightened.png`
			},
			{
				id: "frozen",
				label: "Frozen",
				icon: `${path}frozen.png`
			},
			{
				id: "grappled",
				label: "Grappled",
				icon: `${path}grappled.png`
			},
			{
				id: "haste",
				label: "Haste",
				icon: `${path}haste.png`
			},
			{
				id: "haste-alt",
				label: "Haste (Alt)",
				icon: `${path}haste-alt.png`
			},
			{
				id: "hexed",
				label: "Hexed",
				icon: `${path}hexed.png`
			},
			{
				id: "hungry",
				label: "Hungry",
				icon: `${path}hungry.png`
			},
			{
				id: "hunters-mark",
				label: "Hunter's Mark",
				icon: `${path}hunters-mark.png`
			},
			{
				id: "incapacitated",
				label: "Incapacitated",
				icon: `${path}incapacitated.png`
			},
			{
				id: "incorporeal",
				label: "Incorporeal",
				icon: `${path}incorporeal.png`
			},
			{
				id: "inspired",
				label: "Inspired",
				icon: `${path}inspired.png`
			},
			{
				id: "lamp",
				label: "Lamp",
				icon: `${path}lamp.png`
			},
			{
				id: "paralyzed",
				label: "Paralyzed",
				icon: `${path}paralyzed.png`
			},
			{
				id: "petrified",
				label: "Petrified",
				icon: `${path}petrified.png`
			},
			{
				id: "poisoned",
				label: "Poisoned",
				icon: `${path}poisoned.png`
			},
			{
				id: "prone",
				label: "Prone",
				icon: `${path}prone.png`
			},
			{
				id: "regenerating",
				label: "Regenerating",
				icon: `${path}regenerating.png`
			},
			{
				id: "restrained",
				label: "Restrained",
				icon: `${path}restrained.png`
			},
			{
				id: "shielded",
				label: "Shielded",
				icon: `${path}shielded.png`
			},
			{
				id: "silenced",
				label: "Silenced",
				icon: `${path}silenced.png`
			},
			{
				id: "slowed",
				label: "Slowed",
				icon: `${path}slowed.png`
			},
			{
				id: "slowed-alt",
				label: "Slowed (Alt)",
				icon: `${path}slowed-alt.png`
			},
			{
				id: "stunned",
				label: "Stunned",
				icon: `${path}stunned.png`
			},
			{
				id: "sundered",
				label: "Sundered",
				icon: `${path}sundered.png`
			},
			{
				id: "taunted",
				label: "Taunted",
				icon: `${path}taunted.png`
			},
			{
				id: "thirsty",
				label: "Thirsty",
				icon: `${path}thirsty.png`
			},
			{
				id: "torch",
				label: "Torch",
				icon: `${path}torch.png`
			},
			{
				id: "unconscious",
				label: "Unconscious",
				icon: `${path}unconscious.png`
			},
			{
				id: "webbed",
				label: "Webbed",
				icon: `${path}webbed.png`
			},
			{
				id: "zero",
				label: "Zero",
				icon: `${path}num0.png`
			},
			{
				id: "one",
				label: "One",
				icon: `${path}num1.png`
			},
			{
				id: "two",
				label: "Two",
				icon: `${path}num2.png`
			},
			{
				id: "three",
				label: "Three",
				icon: `${path}num3.png`
			},
			{
				id: "four",
				label: "Four",
				icon: `${path}num4.png`
			},
			{
				id: "five",
				label: "Five",
				icon: `${path}num5.png`
			},
			{
				id: "six",
				label: "Six",
				icon: `${path}num6.png`
			},
			{
				id: "seven",
				label: "Seven",
				icon: `${path}num7.png`
			},
			{
				id: "eight",
				label: "Eight",
				icon: `${path}num8.png`
			},
			{
				id: "nine",
				label: "Nine",
				icon: `${path}num9.png`
			}
		]
	}
  
  const alterHUD = function(app, html, data) {
    for (let img of $('.col.right .control-icon[data-action="effects"] .status-effects > img')) {
      let src = $(img).attr('src');
      if (src == '') {
        $(img).css({
          'visibility': 'hidden'
        });
      } else {
        let title = $(img).attr('title') || $(img).attr('data-condition');
        let div = $('<div>')
          .addClass('effect-container')
          .attr('title', title)
          .insertAfter(img)
          .append(img)
          .append($('<div>').addClass('effect-name').html(title))
        ;
      }
    };
  }
	
	// HOOKS  
  Hooks.once("ready", function() {
		defineStatusIcons();
  });
  
  Hooks.on("renderTokenHUD", (app, html, data) => {
    alterHUD(app, html, data);
  });
  
  Hooks.on("init", function() {
    Token.prototype._drawEffect = async function(src, i, bg, w, tint) {
      const multiplier = 3;
      const divisor = 3 * this.data.height;
      w = (w / 2) * multiplier;
      let tex = await loadTexture(src);
      let icon = this.hud.effects.addChild(new PIXI.Sprite(tex));
      icon.width = icon.height = w;
      icon.y = Math.floor(i / divisor) * w;
      icon.x = (i % divisor) * w;
      if ( tint ) icon.tint = tint;
      this.hud.effects.addChild(icon);
    }
  });
})();